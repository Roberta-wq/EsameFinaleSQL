DROP DATABASE IF EXISTS `ToysGroup`; 
create schema `ToysGroup`;
USE `ToysGroup`;

/** Create tables**/

CREATE TABLE `Product`
(
    `ProdId` INT NOT NULL AUTO_INCREMENT,
    `Name` NVARCHAR(200) NOT NULL,
    `UnitPrice` NUMERIC(10,2) NOT NULL,
    `Description` NVARCHAR(200),
    `Category` NVARCHAR(200),
    CONSTRAINT `PK_Product` PRIMARY KEY  (`ProdId`)
);

CREATE TABLE `Region`
(
    `RegionId` INT NOT NULL AUTO_INCREMENT,
    `Name` NVARCHAR(200) NOT NULL,
    CONSTRAINT `PK_Region` PRIMARY KEY  (`RegionId`)
);

CREATE TABLE `Sales`
(
    `SalesId` INT NOT NULL AUTO_INCREMENT,
     `SalesUnitPrice` NUMERIC(10,2) NOT NULL,
      `Date` DATETIME NOT NULL,
      `Quantity` INT NOT NULL,
      `ProdId` INT NOT NULL,
     `RegionId` INT NOT NULL,
    CONSTRAINT `PK_Sales` PRIMARY KEY  (`SalesId`)
);


/** Foreign keys **/


ALTER TABLE `Sales` ADD CONSTRAINT `FK_SalesProdId`
    FOREIGN KEY (`ProdId`) REFERENCES `Product` (`ProdId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

CREATE INDEX `IFK_SalesProdId` ON `Sales` (`ProdId`); 

ALTER TABLE `Sales` ADD CONSTRAINT `FK_SalesRegionId`
    FOREIGN KEY (`RegionId`) REFERENCES `Region` (`RegionId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

CREATE INDEX `IFK_SalesRegionId` ON `Sales` (`RegionId`); 

/** Populate tables **/

INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Marvel Spider-Man Titan Hero Series', 9.99, 'A 12-inch action figure of Spider-Man with basic articulation and web accessory','Action Figures');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Crayola Inspiration Art Case', 24.99, 'A portable art case with 140 pieces, including crayons, markers, colored pencils, and paper','Arts and Crafts');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Beyblade Burst Rise Hypersphere Set', 34.99, 'A set of two spinning tops and a stadium that allows for high-speed battles and stunts','Battling Toys');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('LEGO Classic Creative Brick Box', 34.99, 'A box of 484 LEGO bricks in 35 different colors, with ideas for building various models','Building and Construction');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Pokemon Sword and Shield Elite Trainer Box', 39.99, 'A box of 8 Pokemon booster packs, 65 card sleeves, 45 energy cards, a player’s guide, and other accessories','Collectible Trading Cards');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Disney Frozen 2 Elsa Costume', 49.99, 'A dress inspired by Elsa’s outfit in Frozen 2, with glittery details and a cape','Costume and Dress-Up');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Barbie Dreamhouse', 199.99, 'A three-story dollhouse with 70 accessories, including furniture, lights, sounds, and a working elevator','Dolls');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('LeapFrog LeapPad Ultimate', 99.99, 'A kid-friendly tablet with a 7-inch screen, 8GB memory, Wi-Fi, and preloaded educational apps and games','Electronic Learning');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Squishmallows 16" Cat Plush', 19.99, 'A soft and squishy plush toy in the shape of a cat, with a cute face and a fluffy tail','Plush');
INSERT INTO `Product` (`Name`, `UnitPrice`, `Description`, `Category` ) VALUES ('Hot Wheels 20-Car Gift Pack', 19.99, 'A pack of 20 die-cast cars in different models, colors, and designs','Vehicles');
INSERT INTO `Region` (`Name`) VALUES ('Canada');
INSERT INTO `Region` (`Name`) VALUES ('Argentina');
INSERT INTO `Region` (`Name`) VALUES ('United Kingdom');
INSERT INTO `Region` (`Name`) VALUES ('Nigeria');
INSERT INTO `Region` (`Name`) VALUES ('Indonesia');
INSERT INTO `Region` (`Name`) VALUES ('New Zealand');
INSERT INTO `Region` (`Name`) VALUES ('Egypt');
INSERT INTO `Region` (`Name`) VALUES ('Cuba');
INSERT INTO `Region` (`Name`) VALUES ('Colombia');
INSERT INTO `Region` (`Name`) VALUES ('Norway');
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (39.99, 50, '2022-02-10', 5, 7 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (30.00, 30, '2021-01-25', 3, 1 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (34.99, 20, '2022-03-5', 4, 5 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (39.99, 40, '2023-02-18', 8, 6 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (34.99, 25, '2024-01-30', 4, 7 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (9.00, 15, '2023-03-12', 1, 1 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (40.00, 35, '2024-02-05', 6, 2 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (34.99, 60, '2023-01-15', 3, 10 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (99.99, 10, '2020-03-20', 8, 8 );
INSERT INTO `Sales` (`SalesUnitPrice`, `Quantity`, `Date`, `ProdId`, `RegionId`) VALUES (32.99, 45, '2021-02-28', 3, 9 );


/** 1 - VERIFICARE CHE I CAMPI PK SIANO UNIVOCI **/
SELECT 
    *
FROM
    Product;
SELECT 
    *
FROM
    Region;
SELECT 
    *
FROM
    Sales;
    
/** 2- ESPORRE L'ELENCO DEI SOLI PRODOTTI VENDUTI E PER OGNUNO DI QUESTI, IL FATTURATO TOTALE PER ANNO **/

SELECT 
    p.prodId,
    p.Name,
    YEAR(s.Date) as Anno,
    SUM(s.Quantity * s.SalesUnitPrice) as Fatturato
FROM
    sales AS s
        JOIN
    product AS p ON p.prodId = s.prodId
GROUP BY p.prodId , p.Name , YEAR(s.Date)
ORDER BY prodId ASC , YEAR(s.Date) ASC;

/** 3- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.  **/

SELECT 
    r.regionId,
    r.Name,
    YEAR(s.Date) AS Anno,
    SUM(s.Quantity * s.SalesUnitPrice) AS Fatturato
FROM
    sales AS s
        JOIN
    region AS r ON r.RegionId = s.RegionId
GROUP BY r.regionId , r.Name , YEAR(s.Date)
ORDER BY anno ASC , Fatturato DESC;

/** 4- qual'e la categoria di articoli maggiormente richiesta dal mercato? **/
    
CREATE VIEW FatturatoProdotti AS
    (SELECT 
        p.prodId, SUM(s.Quantity * s.SalesUnitPrice) AS Fatturato
    FROM
        sales AS s
            JOIN
        product AS p ON p.prodId = s.prodId
    GROUP BY p.prodId , p.Name);


SELECT 
    p.Name, p.Category, fp.Fatturato
FROM
    FatturatoProdotti AS fp
        JOIN
    Product AS p ON p.ProdId = fp.ProdId
WHERE
    fp.Fatturato = (SELECT 
            MAX(Fatturato)
        FROM
            FatturatoProdotti)
;

/**5 - Quali sono i prodotti invenduti ? **/
/**APPROCCIO 1 **/

select *
from product as p
where p.prodId not in (select prodId
from FatturatoProdotti);

/**APPROCCIO 2 **/
select p.*
from product as p
left join sales as s
on s.prodId = p.prodId
where s.salesId is null;

/**6 - Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). **/
select p.ProdId,p.Name, max(s.Date) as UltimaData
from sales as s
join product as p on p.ProdId = s.ProdId
group by p.ProdId;



